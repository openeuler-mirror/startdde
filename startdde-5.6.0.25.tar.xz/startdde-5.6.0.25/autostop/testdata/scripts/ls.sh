#!/bin/bash

ls -l ~/
