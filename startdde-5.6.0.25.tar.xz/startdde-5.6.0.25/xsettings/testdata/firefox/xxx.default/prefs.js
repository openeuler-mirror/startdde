# Mozilla User Preferences

user_pref("layout.css.devPixelsPerPx", "1.55");
user_pref("toolkit.telemetry.previousBuildID", "20160803004522");
user_pref("toolkit.telemetry.reportingpolicy.firstRun", false);
